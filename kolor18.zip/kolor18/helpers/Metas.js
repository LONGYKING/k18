var {GetFriendRequests} = require('../models/RequestModel');
module.exports = {format};