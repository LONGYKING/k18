var clone = {
    time        : {
        type    : Date,
        default : Date.now
    },
}

module.exports = clone;